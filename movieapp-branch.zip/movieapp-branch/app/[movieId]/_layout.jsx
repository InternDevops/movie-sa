import { Stack } from 'expo-router';

const MovieDetailsLayout = () => {
  return <Stack screenOptions={{ headerShown: false }} />;
};

export default MovieDetailsLayout;